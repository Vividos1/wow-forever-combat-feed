# Forever Combat Feed v0.5.0

## Fixes
- Minimap button uses the same border texture (136430), 31x31 frame and top-left texture alignment as Plater's bundled LibDBIcon-1.0 implementation. Includes square-edge placement matching that library. We use no external addon dependencies.
- Incoming damage displays a likely enemy name when a single hostile combatant is detected through nameplates. If more than one is found, it displays `Unknown attacker` because UNIT_COMBAT does not identify the attacker.
- Existing v0.4 features and settings are preserved.

## Testing
1. Replace the old `ForeverCombatFeed` folder, then `/reload`.
2. Drag the minimap button along the square map border, comparing ring alignment with Plater/Questie.
3. Fight one enemy and check incoming labels; then pull two enemies and verify `Unknown attacker` appears rather than an invented name.

**Caveat:** Hostile nameplate visibility and combat flags can vary; single-target labels are inferred, not guaranteed. The Blizzard API available to Forever addons does not supply a reliable attacker name for UNIT_COMBAT. This package has not been tested in the running client.
